#################################### importing libraries ######################################
import numpy as np
import pandas as pd
###############################################################################################

#################################### input_file paths ##########################################
input_file = "./GoldenSetPOSs.txt"
first_order_file = "./first_order_goldenset.csv"
second_order_file = "./second_order_goldenset.csv"
################################################################################################

##################################### Count the uniuew words in corpus #########################
unique_words = set()
with open(input_file, "r") as f:
    lines = f.readlines()
    lines = [i.strip().upper() for i in lines]
    for line in lines:
        for word in line.split(" "):
            if word not in unique_words: unique_words.add(word)
################################################################################################

unique_words1 = list(sorted(unique_words))
unique_words2 = [(i,j) for i in unique_words1 for j in unique_words1]
first_idx  = {k:i for k, i in zip(unique_words1, range(len(unique_words1)))}
second_idx = {k:i for k, i in zip(unique_words2, range(len(unique_words2)))}

# to store the counts in numpy array
first_mat  = np.zeros((len(unique_words1), len(unique_words1)))
second_mat = np.zeros((len(unique_words2), len(unique_words1)))

with open(input_file, "r") as f:
    lines = f.readlines()
    lines = [i.strip() for i in lines]
    for line in lines:
        words = line.split(" ")
        for i in range(len(words)):
            if i == 0: continue #if there is only one word, no need to count.
            elif i == 1: #this will have only first order matrix
                token0 = words[i-1]
                token1 = words[i]
                first_mat[first_idx.get(token0)][first_idx.get(token1)] += 1
            else: # thiw case will have both first and second order
                token0 = words[i-2]
                token1 = words[i-1]
                token2 = words[i]
                first_mat[first_idx.get(token1)][first_idx.get(token2)] += 1
                second_mat[second_idx.get((token0, token1))][first_idx.get(token2)] += 1


# creatind dataframe and then saving the data.
s = first_mat.sum(axis=1, keepdims=True) #sum the array
first_mat = np.divide(first_mat,s, out=np.zeros_like(first_mat), where=s!=0) #devide and avoid the zero division
df1 = pd.DataFrame(data = first_mat, columns = unique_words1, index = unique_words1)

s = second_mat.sum(axis=1, keepdims=True)
second_mat = np.divide(second_mat,s, out=np.zeros_like(second_mat), where=s!=0)
df2 = pd.DataFrame(data = second_mat, columns = unique_words1, index = unique_words2)


df1.to_csv(first_order_file)
df2.to_csv(second_order_file)
