# importing library
import spacy

######################################## loading Spacy ###################################################
# https://spacy.io/usage/linguistic-features
print("loading the spacy model...")
nlp = spacy.load("en_core_web_sm")
print("loading done!\n")
###########################################################################################################

########################################## path  of text file ###################################################
input_path = "./filtered-methods.txt"
output_path = "./pos_tag_output.txt"

# dictionary of abbreviation as key and value as its full form: keep them in lower case
# add more fnd out
abbs_full_form = {'id': 'indentity'}
###########################################################################################################

################################# helpful functions for case-matching  ###########################################
def load_file(path):
    """
    function to load the text file.
    returns the list of phrases
    """
    with open(path, 'r') as f:
        lines = f.readlines()
        phrases = [i.strip() for i in lines]
    return phrases

def pos_tagger(ls):
    """
    ls: list of phrase
        returns list of  'POS sequences'
    """
    new_ls = []
    for phrase in ls:
        temp = []
        for word in phrase.split(" "):
            if abbs_full_form.get(word.lower()): temp.append(abbs_full_form.get(word.lower()))
            else: temp.append(word)
        phrase = " ".join(temp)
        doc = nlp(phrase)
        temp = []
        for token in doc: temp.append(token.pos_)
        new_ls.append(" ".join(temp))
    return new_ls

###########################################################################################################
def main():
    phrase = load_file(input_path)
    POS_tags = pos_tagger(phrase)
    with open(output_path, "w") as f:
        f.write("\n".join(POS_tags))

if __name__ == "__main__":
    main()
