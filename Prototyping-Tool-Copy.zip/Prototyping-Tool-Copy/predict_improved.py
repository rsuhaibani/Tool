#################################### importing libraries #################################################################
import numpy as np
import pandas as pd
from sklearn.model_selection import KFold
##########################################################################################################################

#################################### input_file paths #####################################################################
input_file = "./all_tagged_notepade_dataset_no_filter.txt"
# first_order_file = "./first_order.csv"
# second_order_file = "./second_order.csv"
###########################################################################################################################

############################## using whole corpus only for all words# #####################################################
unique_words = set()
with open(input_file, "r") as f:
    lines = f.readlines()
    lines = [i.strip().upper()+" EOS" for i in lines]
    for line in lines:
        for word in line.split(" "):
            if word not in unique_words: unique_words.add(word)
unique_words1 = list(sorted(unique_words))
unique_words2 = [(i,j) for i in unique_words1 for j in unique_words1]
first_idx  = {k:i for k, i in zip(unique_words1, range(len(unique_words1)))}
second_idx = {k:i for k, i in zip(unique_words2, range(len(unique_words2)))}
##############################################################################################################################

######################################## function  ###########################################################################
def train(lines, unique_word1 = unique_words1, unique_word2 = unique_words1, idx1 = first_idx, idx2 = second_idx):
    """
    lines: list of phrases
    """
    # to store the counts in numpy array
    first_mat  = np.zeros((len(unique_words1), len(unique_words1)))
    second_mat = np.zeros((len(unique_words2), len(unique_words1)))

    for line in lines:
        words = line.split(" ")
        for i in range(len(words)):
            if i == 0: continue #if there is only one word, no need to count.
            elif i == 1: #this will have only first order matrix
                token0 = words[i-1]
                token1 = words[i]
                first_mat[first_idx.get(token0)][first_idx.get(token1)] += 1
            else: # thiw case will have both first and second order
                token0 = words[i-2]
                token1 = words[i-1]
                token2 = words[i]
                first_mat[first_idx.get(token1)][first_idx.get(token2)] += 1
                second_mat[second_idx.get((token0, token1))][first_idx.get(token2)] += 1
    # creatind dataframe and then saving the data.
    s = first_mat.sum(axis=1, keepdims=True) #sum the array
    first_mat = np.divide(first_mat,s, out=np.zeros_like(first_mat), where=s!=0) #devide and avoid the zero division
    df1 = pd.DataFrame(data = first_mat, columns = unique_words1, index = unique_words1)

    s = second_mat.sum(axis=1, keepdims=True)
    second_mat = np.divide(second_mat,s, out=np.zeros_like(second_mat), where=s!=0)
    df2 = pd.DataFrame(data = second_mat, columns = unique_words1, index = unique_words2)
    return df1, df2

def predict_next_word(current_state, first_order_df, iterations = 100, all_words=unique_words1):
    """
    current_state: current word
    first_order_df: first order transition matrix
    all_next_possible_words: list of all possible words
        predict the next sate using current_state and first order transition matrix
    """
    probabilty = first_order_df.loc[current_state,:].values
    if sum(probabilty) == 0:probabilty = None
    next_states = []
    for _ in range(iterations):
        next_states.append(str(np.random.choice(all_words, 1, p = probabilty, replace=False)[0]))
    next_state = max(set(next_states), key = next_states.count)
    return next_state

def predict_phrase(first_state, first_order_df, max_words = 6):
    """
    first_state: first word of the phrase
    max_words: maximum possible lenght of phrase (in case of no `EOS`)
    """
    pred = first_state
    for i in range(max_words-1):
        temp = predict_next_word(first_state, first_order_df)
        if temp == "EOS": break
        else: pred += " "; pred += temp
        first_state = temp
    return pred

def performance(true_lines, pred_lines):
    """
    true_lines: list of true lines
    pred_lines: list of predicted lines
    """
    is_correct = []
    for i in range(len(true_lines)):
        # if true_lines[i].replace(" EOS", "") == pred_lines[i]: is_correct.append(1)
        if true_lines[i].split(" ")[:2] == pred_lines[i].split(" ")[:2]: is_correct.append(1)
        else: is_correct.append(0)
    return sum(is_correct)*100/len(is_correct), is_correct
######################################################################################################################################

with open(input_file, "r") as f:
    lines = f.readlines()
    lines = [i.strip().upper()+" EOS" for i in lines if len(i.split(" "))>1]


##################################################  KFold training and testing ######################################################
kf = KFold(n_splits=5)
train_perfs = []
test_perfs = []
fold = 0
for train_idx, test_idx in kf.split(lines):
    print(f"testing with fold = {fold+1} and training with remaining....")
    train_lines = [lines[i] for i in train_idx]
    test_lines = [lines[i] for i in test_idx]
    # training the model
    mat1, mat2 = train(train_lines)
    #doing prediction
    pred_train = []
    pred_test  = []
    for p_train in train_lines:
        first_tag = p_train.split(" ")[0]
        pred_train.append(predict_phrase(first_tag, mat1))
    for p_test in test_lines:
        first_tag = p_test.split(" ")[0]
        pred_test.append(predict_phrase(first_tag, mat1))
    # checking the performance
    train_acc, train_label = performance(train_lines, pred_train)
    test_acc, test_label = performance(test_lines, pred_test)
    train_perfs.append(train_acc)
    test_perfs.append(test_acc)
    fold+=1
######################################################################################################################################
print("Train performance: ", train_perfs)
print("Test performance: ", test_perfs)

print("%Accuracy for Train: ", sum(train_perfs)/len(train_perfs))
print("%Accuracy for Test: ", sum(test_perfs)/len(test_perfs))
