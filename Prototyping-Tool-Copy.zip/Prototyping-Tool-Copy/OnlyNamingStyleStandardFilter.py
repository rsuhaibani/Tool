# last updated: 22/septmber/2020

# A filter for checking the naming style adherence for methods, if the provided name does not follow
# a certain common naming style it is omitted from the output file. Also, it is not allowed to have more than naming style in a given text.



# Importing splitting library with its best algorithm for splitting source code identfiers 
from spiral import ronin


########################################## path  of text file ###################################################
input_path = "./UnsplittedMethods.txt" # The method list you want to check. 
output_path = "./output.txt" # The name of the output file. 
exception_list = ["HTML", "URL", "VPN", "IP"] # Those are the allowed abbreviations in a name, if a method contains one of them it is still not violating our styles..
##################################################################################################################



########################################## helpful functions   ###################################################
def load_file(path):
    """
    function to load the text file.
    returns the list of phrases
    """
    with open(path, 'r') as f:
        lines = f.readlines()
        phrases = [i.strip() for i in lines]
    return phrases

def follow_underscore(text):
    """
    function for underscore format
    text: strin
        # Rule-1: if text starts with `_` or ends with `_` or does not contain `_`: it's not a phrase so return False
        # Rule-2: if text have `-`, it's not a phrase. So return False
        # Rule-3: if text has even a single upper-case, it's not a phrse. So return False
        # Rule-4: if text has more than one continuous `_`, it's not a phrase. So return Flase
        If phrase passes all above rules consider that as a phrase and return True
    """
    # Rule-1
    if ((text.startswith("_")) or (text.endswith('_')) or ("_" not in text)): return False
    # Rule-2:
    if "-" in text: return False # for text like "read_book-ok"

    # Rule-3 & Rule-4
    continuous_underscrore_count = 0
    for letter in text[1:]:
        if letter.isupper(): return False #Rule-3

        if letter.isdigit(): continue #letter.islower() or
        if letter == "_":continuous_underscrore_count+=1
        else: continuous_underscrore_count = 0
        if continuous_underscrore_count>=2: return False # Rule-4
    return True

def follow_KebabCase(text):
    """
    function for KebabCase format
    text: string
        # Rule-1: if text starts with `-` or ends with `-` or does not contain `-`: it's not a phrase so return False
        # Rule-2: if text have `_`, it's not a phrase. So return False
        # Rule-3: if text has even a single upper-case, it's not a phrse. So return False
        # Rule-4: if text has more than one continuous `-`, it's not a phrase. So return Flase
        If phrase passes all above rule consider that as a phrase and return True

    """
    # Rule-1
    if ((text.startswith("-")) or (text.endswith('-')) or ("-" not in text)): return False
    # Rule-2:
    if "_" in text: return False # for text like "read_book-ok"

    # Rule-3 & Rule-4
    continuous_dash_count = 0
    for letter in text[1:]:
        if letter.isupper(): return False #Rule-3

        if letter.isdigit(): continue #letter.islower() or
        if letter == "-":continuous_dash_count+=1
        else: continuous_dash_count = 0
        if continuous_dash_count>=2: return False # Rule-4
    return True

def follow_camelCase(text):
    """
    function for camelCase format
    text: string
        # Rule-1: text should not contain `-` or `_`. If yes then return False
        # Rule-2: first element must be lower-case, otherwise not a phrase. So return False
        # Rule-3: text must have at least one upper letter, if not return False
        # Rule-4: text should not have more than one upper letter continuously, if yes return False
    """
    if (('_' in text) or ('-' in text)): return False # Rule-1
    if not text[0].islower(): return False # Rule-2

    # Rule-3 and Rule-4
    is_upper = False
    continuous_upper_letter_count = 0
    for letter in text[1:]:
        if letter.isupper():
            continuous_upper_letter_count += 1
            is_upper = True # a variable for: Rule-3
        else:continuous_upper_letter_count=0
        if continuous_upper_letter_count>=2: return False #Rule-4
    if is_upper: return True # Rule-3
    else: return False

def follow_PascalCase(text):
    """
    function for PascalCase format
    text: string
        # Rule-1: text should not contain `-` or `_`. If yes then return False
        # Rule-2: first element must be upper-case, otherwise not a phrase. So return False
        # Rule-3: text must have at least one letter other than upper-case, if not return False
        # Rule-4: text should not have more than one upper letter continuously, if yes return False
    """
    if (('_' in text) or ('-' in text)): return False # Rule-1
    if not text[0].isupper(): return False # Rule-2

    # Rule-3 and Rule-4
    is_lower = False
    continuous_upper_letter_count = 0
    for letter in text[1:]:
        if letter.isupper():continuous_upper_letter_count += 1
        else:continuous_upper_letter_count=0; is_lower = True
        if continuous_upper_letter_count>=2: return False #Rule-4
    if is_lower: return True # Rule-3
    else: return False

def handle_exception(text, exp_list):
    """
    text: string
    exp_list: list of exception words
    function to deal the exception case
    """
    if text.startswith("_") or text.startswith("-") or text.endswith("_") or text.endswith("-"): return False
    for word in exp_list:
        if word in text: return True
    else: return False

def filter_phrases(ls, exp_list):
    """
    ls: list of phrase
        removes the phrase that does not follow the atleast one rule of above four rules
        this will return updates list of phrases
    """
    new_ls = []
    for phrase in ls:
        if (follow_underscore(phrase) or follow_KebabCase(phrase)
            or follow_camelCase(phrase) or follow_PascalCase(phrase)
            or handle_exception(phrase, exp_list)):
            new_ls.append(phrase)
    return new_ls

def clean_phrase(ls):
    """
    ls: list of phrases
        this will split the phrases and return the list of split phrases
    """
    new_ls = []
    for phrase in ls:
        if follow_underscore(phrase): new_ls.append(" ".join((phrase.split("_")))); continue
        if follow_KebabCase(phrase): new_ls.append(" ".join((phrase.split("_")))); continue
        new_ls.append(" ".join(ronin.split(phrase)))
    return new_ls

##################################################################################################################
def main():
    print("loading the text file...")
    phrases = load_file(input_path)
    print(f"loadig done! there are {len(phrases)} phrases.")
    print("filtering the phrases that are not ok...")
    phrases = filter_phrases(phrases, exception_list)
    print(f"after filtering, there are {len(phrases)} phrases.")
    print("spitting the phrases...")
    phrases = clean_phrase(phrases)
    print("saving the output file...")
    with open(output_path, "w") as f:
        f.write("\n".join(phrases))

if __name__ == "__main__":
    main()
