
# # The following code is for filtering given method names based on the 10 method standards # #
# # The input file is a list of a random unsplitted method names # # 
# # The output is a list of good method names that meet all the 10 standards, and they are # #
# # all after splitting using spiral source code identifier splitter, and specifically ronin spliting algorthim. # #
# # There are a list of exception abbreviations/acronyms that are allowed to appear in a method name as commonnly used ones that we can add on the go # #



# importing library
from spiral import ronin
from nltk.corpus import wordnet
from itertools import chain
import spacy

######################################## loading Spacy ###################################################
# https://spacy.io/usage/linguistic-features
print("loading the spacy model...")
nlp = spacy.load("en_core_web_sm")
print("loading done!\n")
###########################################################################################################

########################################## path  of text file ###################################################
input_path = "./UnsplittedMethodsNotepadplusplus.txt"
output_path = "./filtred_Notepadplusplus.txt"
exception_list = ["HTML", "URL", "VPN", "IP", "GL"]
#exception_list = "./exception_list.txt" # This line for loading a certain list of abbreviations from a text file.

# 1. some list of words if WordNet does not have it, but consider them as word
#NOTE: if you want to add words then add in lower-case only
new_words = ["url",  "gl", " sql", "db", "gui", "fifo", "dom", "tiff", "remap"]
# 3. phrase should not contain single letters and these words: string,str,integer,int,character, gimp,get
not_included_words = ['string','str','integer','int','character','char','gimp','tx']
# 5. if phrases starts with any of these word remove them and if word is there BUT NOT in starting, then consider that phrase
special_words = ["get", "set","is","tera"]
##################################################################################################################

##################################################################################################################
##################################################################################################################

################################# helpful functions for case-matching  ###########################################
def load_file(path):
    """
    function to load the text file.
    returns the list of phrases
    """
    with open(path, 'r') as f:
        lines = f.readlines()
        phrases = [i.strip() for i in lines]
    return phrases

def follow_underscore(text):
    """
    function for underscore format
    text: strin
        # Rule-1: if text starts with `_` or ends with `_` or does not contain `_`: it's not a phrase so return False
        # Rule-2: if text have `-`, it's not a phrase. So return False
        # Rule-3: if text has even a single upper-case, it's not a phrse. So return False
        # Rule-4: if text has more than one continuous `_`, it's not a phrase. So return Flase
        If phrase passes all above rule consider that as a phrase and return True
    """
    # Rule-1
    if ((text.startswith("_")) or (text.endswith('_')) or ("_" not in text)): return False
    # Rule-2:
    if "-" in text: return False # for text like "read_book-ok"

    # Rule-3 & Rule-4
    continuous_underscrore_count = 0
    for letter in text[1:]:
        if letter.isupper(): return False #Rule-3

        if letter.isdigit(): continue #letter.islower() or
        if letter == "_":continuous_underscrore_count+=1
        else: continuous_underscrore_count = 0
        if continuous_underscrore_count>=2: return False # Rule-4
    return True

def follow_KebabCase(text):
    """
    function for KebabCase format
    text: string
        # Rule-1: if text starts with `-` or ends with `-` or does not contain `-`: it's not a phrase so return False
        # Rule-2: if text have `_`, it's not a phrase. So return False
        # Rule-3: if text has even a single upper-case, it's not a phrse. So return False
        # Rule-4: if text has more than one continuous `-`, it's not a phrase. So return Flase
        If phrase passes all above rule consider that as a phrase and return True

    """
    # Rule-1
    if ((text.startswith("-")) or (text.endswith('-')) or ("-" not in text)): return False
    # Rule-2:
    if "_" in text: return False # for text like "read_book-ok"

    # Rule-3 & Rule-4
    continuous_dash_count = 0
    for letter in text[1:]:
        if letter.isupper(): return False #Rule-3

        if letter.isdigit(): continue #letter.islower() or
        if letter == "-":continuous_dash_count+=1
        else: continuous_dash_count = 0
        if continuous_dash_count>=2: return False # Rule-4
    return True

def follow_camelCase(text):
    """
    function for camelCase format
    text: string
        # Rule-1: text should not contain `-` or `_`. If yes then return False
        # Rule-2: first element must be lower-case, otherwise not a phrase. So return False
        # Rule-3: text must have at least one upper letter, if not return False
        # Rule-4: text should not have more than one upper letter continuously, if yes return False
    """
    if (('_' in text) or ('-' in text)): return False # Rule-1
    if not text[0].islower(): return False # Rule-2

    # Rule-3 and Rule-4
    is_upper = False
    continuous_upper_letter_count = 0
    for letter in text[1:]:
        if letter.isupper():
            continuous_upper_letter_count += 1
            is_upper = True # a variable for: Rule-3
        else:continuous_upper_letter_count=0
        if continuous_upper_letter_count>=2: return False #Rule-4
    if is_upper: return True # Rule-3
    else: return False

def follow_PascalCase(text):
    """
    function for PascalCase format
    text: string
        # Rule-1: text should not contain `-` or `_`. If yes then return False
        # Rule-2: first element must be upper-case, otherwise not a phrase. So return False
        # Rule-3: text must have at least one letter other than upper-case, if not return False
        # Rule-4: text should not have more than one upper letter continuously, if yes return False
    """
    if (('_' in text) or ('-' in text)): return False # Rule-1
    if not text[0].isupper(): return False # Rule-2

    # Rule-3 and Rule-4
    is_lower = False
    continuous_upper_letter_count = 0
    for letter in text[1:]:
        if letter.isupper():continuous_upper_letter_count += 1
        else:continuous_upper_letter_count=0; is_lower = True
        if continuous_upper_letter_count>=2: return False #Rule-4
    if is_lower: return True # Rule-3
    else: return False

def handle_exception(text, exp_list):
    """
    text: string
    exp_list: list of exception words
    function to deal the exception case
    """
    if text.startswith("_") or text.startswith("-") or text.endswith("_") or text.endswith("-"): return False
    for word in exp_list:
        if word in text: return True
    else: return False

def filter_phrases(ls, exp_list):
    """
    ls: list of phrase
        removes the phrase that does not follow the atleast one rule of above four rules
        this will return updates list of phrases
    """
    new_ls = []
    for phrase in ls:
        if (follow_underscore(phrase) or follow_KebabCase(phrase)
            or follow_camelCase(phrase) or follow_PascalCase(phrase)
            or handle_exception(phrase, exp_list)):
            new_ls.append(phrase)
    return new_ls

def clean_phrase(ls):
    """
    ls: list of phrases
        this will split the phrases and return the list of split phrases
    """
    new_ls = []
    for phrase in ls:
        if follow_underscore(phrase): new_ls.append(" ".join((phrase.split("_")))); continue
        if follow_KebabCase(phrase): new_ls.append(" ".join((phrase.split("_")))); continue
        new_ls.append(" ".join(ronin.split(phrase)))
    return new_ls

################################# helpful functions for 5-conditions  ###########################################
def condition1(phrases, new_list):
    """
    phrases: list of phrases
    new_list: list of new words
        removing the phrase if it has non-engling word and returning the updated list of phrases
    """
    ls = []
    for phrase in phrases:
        for word in phrase.split(" "):
            if (len(wordnet.synsets(word))==0) and (word.lower() not in new_list): break
        else: ls.append(phrase)
    return ls

def condition2(phrases, nlp):
    """
    phrases: list of phrases,
    nlp: spacy.lang.en.English :after loading the model
        removing the phrase that don't have 'VERB' and returning the updated list of phrases
    """
    ls = []
    for phrase in phrases:
        doc = nlp(phrase)
        POS = []
        for token in doc:POS.append(token.pos_)
        if "VERB" in POS:ls.append(phrase)
    return ls

def condition3(ls, not_included_words):
    """
    ls: list of list of phrases,
    not_included_words: list of Not inluded words
        removing the phrases that have one letter word or some define word and returning the updated list of phrases
    """
    new_ls = []
    for phrase in ls:
        for word in phrase.split(" "):
            if (word.lower() in not_included_words) or (len(word) == 1):break
        else: new_ls.append(phrase)
    return new_ls

def condition4(ls):
    """
    ls: list of list of phrases,
        moving the phrase that have more than 5 words and returning the updated list of phrases
    """
    return list(filter(lambda x: True if len(x.split(" ")) <= 6 else False, ls))

def condition5(ls, special_list):
    """
    ls: list of phrase
    special_list: list of special words
        removing the phrases that start with special words and returning the updated list of phrases
    """
    new_ls = []
    for phrase in ls:
        for word in special_list:
            if phrase.lower().split(" ")[0].strip() == word:break
        else:new_ls.append(phrase)
    return new_ls

##################################################################################################################
##################################################################################################################
def main():
    print("loading the text file...")
    phrases = load_file(input_path)
    print(f"loadig done! there are {len(phrases)} phrases.")

    print("filtering the phrases that are not ok...")
    phrases = filter_phrases(phrases, exception_list)
    print(f"after filtering, there are {len(phrases)} phrases.")

    print("spitting the phrases...")
    phrases = clean_phrase(phrases)

    phrases = condition4(phrases)
    print(f"There are: {len(phrases)} phrases, after removing the phrases that have more than 6 words")

    phrases = condition3(phrases, not_included_words)
    print(f"There are: {len(phrases)} phrases, after removing the phrases that have one letter word or have defined word")

    phrases = condition5(phrases, special_words)
    print(f"There are: {len(phrases)} phrases, after removing that start with special word")

    phrases = condition1(phrases, new_words)
    print(f"There are: {len(phrases)} phrases, after removing the phrases that have Non-English word")

    phrases = condition2(phrases, nlp)
    print(f"There are: {len(phrases)} phrases, after removing the phrases that don't have `VERB`")

    print("saving the output file...")
    with open(output_path, "w") as f:
        f.write("\n".join(phrases))

if __name__ == "__main__":
    main()
